package com.example.prg5_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prg5JavaApplicationTests {

	@Test
	void contextLoads() {
	}

}

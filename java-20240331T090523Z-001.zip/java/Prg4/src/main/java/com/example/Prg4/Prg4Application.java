package com.example.Prg4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prg4Application {

	public static void main(String[] args) {
		SpringApplication.run(Prg4Application.class, args);
	}

}
